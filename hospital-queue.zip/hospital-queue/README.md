# Hospital Queue (prototype)

Spring Boot + H2 (in-memory, zero setup). Needs Java 17+ and Maven.

## Run
    mvn spring-boot:run

## Try it
    # Register patients
    curl -X POST localhost:8080/api/register -H "Content-Type: application/json" \
      -d '{"patientName":"Rahul","age":30,"symptoms":"BP medicine refill"}'
    curl -X POST localhost:8080/api/register -H "Content-Type: application/json" \
      -d '{"patientName":"Anita","age":70,"symptoms":"chest pain"}'

    # See the queue (Anita should be #1 even though she came second)
    curl localhost:8080/api/queue

    # Check one token
    curl localhost:8080/api/token/1

    # Staff: mark in progress / done
    curl -X PUT "localhost:8080/api/token/2/status?value=DONE"

DB console: http://localhost:8080/h2-console  (JDBC URL: jdbc:h2:mem:hospital)
