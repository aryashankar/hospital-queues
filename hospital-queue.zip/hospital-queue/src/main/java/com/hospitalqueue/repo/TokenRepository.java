package com.hospitalqueue.repo;

import com.hospitalqueue.model.Status;
import com.hospitalqueue.model.Token;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TokenRepository extends JpaRepository<Token, Long> {

    // Highest urgency first, then first-come-first-served
    List<Token> findByStatusOrderByUrgencyScoreDescCreatedAtAsc(Status status);
}
