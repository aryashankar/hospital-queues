package com.hospitalqueue.service;

import com.hospitalqueue.model.Status;
import com.hospitalqueue.model.Token;
import com.hospitalqueue.repo.TokenRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class QueueService {

    private final TokenRepository repo;
    private final TriageService triage;

    public QueueService(TokenRepository repo, TriageService triage) {
        this.repo = repo;
        this.triage = triage;
    }

    public Token register(String name, int age, String symptoms) {
        int score = triage.score(symptoms, age);
        return repo.save(new Token(name, age, symptoms, score));
    }

    public List<Token> waiting() {
        return repo.findByStatusOrderByUrgencyScoreDescCreatedAtAsc(Status.WAITING);
    }

    public Token get(Long id) {
        return repo.findById(id).orElseThrow(() -> new NoSuchElementException("Token " + id + " not found"));
    }

    /** 1-based position in the waiting queue, or 0 if not waiting. */
    public int positionOf(Token token) {
        if (token.getStatus() != Status.WAITING) return 0;
        List<Token> queue = waiting();
        for (int i = 0; i < queue.size(); i++) {
            if (queue.get(i).getId().equals(token.getId())) return i + 1;
        }
        return 0;
    }

    public Token updateStatus(Long id, Status status) {
        Token t = get(id);
        t.setStatus(status);
        return repo.save(t);
    }
}
