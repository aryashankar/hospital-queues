package com.hospitalqueue.service;

import org.springframework.stereotype.Service;

import java.util.Map;

/** Rule-based triage. No AI, no drama. Score 0-100, higher = more urgent. */
@Service
public class TriageService {

    private static final Map<String, Integer> KEYWORDS = Map.ofEntries(
        Map.entry("chest pain", 100),
        Map.entry("unconscious", 100),
        Map.entry("stroke", 100),
        Map.entry("breathing", 90),
        Map.entry("bleeding", 85),
        Map.entry("accident", 80),
        Map.entry("fracture", 60),
        Map.entry("high fever", 55),
        Map.entry("fever", 40),
        Map.entry("vomiting", 40),
        Map.entry("cough", 25),
        Map.entry("checkup", 10),
        Map.entry("refill", 10)
    );

    private static final int DEFAULT_SCORE = 20;

    public int score(String symptoms, int age) {
        String text = symptoms == null ? "" : symptoms.toLowerCase();

        int base = KEYWORDS.entrySet().stream()
                .filter(e -> text.contains(e.getKey()))
                .mapToInt(Map.Entry::getValue)
                .max()
                .orElse(DEFAULT_SCORE);

        // Very young and elderly patients get bumped up
        if (age < 5 || age > 65) base += 10;

        return Math.min(base, 100);
    }
}
