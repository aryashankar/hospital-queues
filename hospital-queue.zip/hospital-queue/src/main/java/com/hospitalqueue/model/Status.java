package com.hospitalqueue.model;

public enum Status {
    WAITING, IN_PROGRESS, DONE
}
