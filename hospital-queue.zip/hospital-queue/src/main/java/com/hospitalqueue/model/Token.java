package com.hospitalqueue.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Token {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String patientName;
    private int age;
    private String symptoms;
    private int urgencyScore;

    @Enumerated(EnumType.STRING)
    private Status status = Status.WAITING;

    private LocalDateTime createdAt = LocalDateTime.now();

    public Token() {}

    public Token(String patientName, int age, String symptoms, int urgencyScore) {
        this.patientName = patientName;
        this.age = age;
        this.symptoms = symptoms;
        this.urgencyScore = urgencyScore;
    }

    public Long getId() { return id; }
    public String getPatientName() { return patientName; }
    public int getAge() { return age; }
    public String getSymptoms() { return symptoms; }
    public int getUrgencyScore() { return urgencyScore; }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
