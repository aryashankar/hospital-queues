package com.hospitalqueue.controller;

import com.hospitalqueue.model.Status;
import com.hospitalqueue.model.Token;
import com.hospitalqueue.service.QueueService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class QueueController {

    public record RegisterRequest(String patientName, int age, String symptoms) {}

    public record TokenView(Long id, String patientName, int age, String symptoms,
                            int urgencyScore, Status status, int position) {}

    private final QueueService service;

    public QueueController(QueueService service) {
        this.service = service;
    }

    private TokenView view(Token t) {
        return new TokenView(t.getId(), t.getPatientName(), t.getAge(), t.getSymptoms(),
                t.getUrgencyScore(), t.getStatus(), service.positionOf(t));
    }

    @PostMapping("/register")
    public TokenView register(@RequestBody RegisterRequest req) {
        return view(service.register(req.patientName(), req.age(), req.symptoms()));
    }

    @GetMapping("/queue")
    public List<TokenView> queue() {
        return service.waiting().stream().map(this::view).toList();
    }

    @GetMapping("/token/{id}")
    public TokenView token(@PathVariable Long id) {
        return view(service.get(id));
    }

    @PutMapping("/token/{id}/status")
    public TokenView updateStatus(@PathVariable Long id, @RequestParam Status value) {
        return view(service.updateStatus(id, value));
    }

    @ExceptionHandler(NoSuchElementException.class)
    public ResponseEntity<String> notFound(NoSuchElementException e) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
    }
}
